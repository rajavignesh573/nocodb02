#!/bin/bash

# Product Matcher Migration Deployment Script
# This script deploys all the changes to fix the Product Matcher functionality

set -e  # Exit on any error

echo "🚀 Starting Product Matcher Migration Deployment..."

# Configuration
BACKUP_DIR="/backup/product-matcher-$(date +%Y%m%d-%H%M%S)"
NOCODB_PATH="/home/nocodb/nocorun_vg/nocodb"
MIGRATION_PATH="$NOCODB_PATH/deploy_migration"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running from correct directory
if [ ! -d "$MIGRATION_PATH" ]; then
    print_error "Migration files not found at $MIGRATION_PATH"
    print_error "Please run this script from the NocoDB root directory"
    exit 1
fi

# Create backup directory
print_status "Creating backup directory: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# Backup current files
print_status "Backing up current files..."
cp packages/nc-product-matching/src/services/ProductMatchingService.ts "$BACKUP_DIR/" 2>/dev/null || print_warning "ProductMatchingService.ts not found"
cp packages/nc-product-matching/dist/services/ProductMatchingService.js "$BACKUP_DIR/" 2>/dev/null || print_warning "ProductMatchingService.js not found"
cp packages/nc-product-matching/server.js "$BACKUP_DIR/" 2>/dev/null || print_warning "server.js not found"
cp packages/nc-product-matching/src/helpers/EnhancedMatchingEngine.ts "$BACKUP_DIR/" 2>/dev/null || print_warning "EnhancedMatchingEngine.ts not found"
cp packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js "$BACKUP_DIR/" 2>/dev/null || print_warning "EnhancedMatchingEngine.js not found"
cp packages/nc-gui/components/workspace/product-matcher/view.vue "$BACKUP_DIR/" 2>/dev/null || print_warning "view.vue not found"
cp packages/nc-gui/composables/useProductMatchingApi.ts "$BACKUP_DIR/" 2>/dev/null || print_warning "useProductMatchingApi.ts not found"
cp packages/nc-gui/composables/useProductMatching.ts "$BACKUP_DIR/" 2>/dev/null || print_warning "useProductMatching.ts not found"

print_status "Backup completed at: $BACKUP_DIR"

# Deploy backend files
print_status "Deploying backend files..."
cp "$MIGRATION_PATH/backend/packages/nc-product-matching/server.js" packages/nc-product-matching/
cp "$MIGRATION_PATH/backend/packages/nc-product-matching/src/services/ProductMatchingService.ts" packages/nc-product-matching/src/services/
cp "$MIGRATION_PATH/backend/packages/nc-product-matching/dist/services/ProductMatchingService.js" packages/nc-product-matching/dist/services/
cp "$MIGRATION_PATH/backend/packages/nc-product-matching/src/helpers/EnhancedMatchingEngine.ts" packages/nc-product-matching/src/helpers/
cp "$MIGRATION_PATH/backend/packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js" packages/nc-product-matching/dist/helpers/

# Deploy frontend files
print_status "Deploying frontend files..."
cp "$MIGRATION_PATH/frontend/packages/nc-gui/components/workspace/product-matcher/view.vue" packages/nc-gui/components/workspace/product-matcher/
cp "$MIGRATION_PATH/frontend/packages/nc-gui/composables/useProductMatchingApi.ts" packages/nc-gui/composables/
cp "$MIGRATION_PATH/frontend/packages/nc-gui/composables/useProductMatching.ts" packages/nc-gui/composables/

print_status "All files deployed successfully!"

# Verify critical changes
print_status "Verifying critical changes..."

# Check if threshold fix was applied
if grep -q "similarity.overall < 0.10" packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js; then
    print_status "✅ Minimum score threshold fix applied (30% → 10%)"
else
    print_error "❌ Minimum score threshold fix NOT applied"
fi

# Check if const fix was applied
if grep -q "let options:" packages/nc-gui/composables/useProductMatching.ts; then
    print_status "✅ JavaScript const fix applied"
else
    print_error "❌ JavaScript const fix NOT applied"
fi

# Check if product category source was updated
if grep -q "nc_external_products" packages/nc-product-matching/dist/services/ProductMatchingService.js; then
    print_status "✅ Product category source updated to nc_external_products"
else
    print_error "❌ Product category source NOT updated"
fi

print_status "Deployment completed successfully!"
print_status "Backup location: $BACKUP_DIR"
print_warning "Please restart your services to apply the changes:"
echo ""
echo "Backend:"
echo "  cd packages/nc-product-matching && DB_NAME=pim DB_USER=devuser DB_PASSWORD=VerifyTen102025 HOST=0.0.0.0 PORT=8087 pnpm start"
echo ""
echo "Frontend:"
echo "  cd packages/nc-gui && HOST=0.0.0.0 PORT=3005 NUXT_PUBLIC_NC_BACKEND_URL=http://localhost:8086 pnpm run dev"
echo ""
print_status "For rollback, restore files from: $BACKUP_DIR"
