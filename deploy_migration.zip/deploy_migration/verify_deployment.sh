#!/bin/bash

# Product Matcher Deployment Verification Script
# This script verifies that all changes were applied correctly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_info() {
    echo -e "${BLUE}[i]${NC} $1"
}

echo "🔍 Product Matcher Deployment Verification"
echo "=========================================="

# Check if we're in the right directory
if [ ! -d "packages/nc-product-matching" ] || [ ! -d "packages/nc-gui" ]; then
    print_error "Not in NocoDB root directory. Please run from the correct location."
    exit 1
fi

# Verification counters
PASSED=0
FAILED=0

# Function to check file content
check_file_content() {
    local file="$1"
    local pattern="$2"
    local description="$3"
    
    if [ -f "$file" ]; then
        if grep -q "$pattern" "$file"; then
            print_status "$description"
            ((PASSED++))
        else
            print_error "$description"
            ((FAILED++))
        fi
    else
        print_error "File not found: $file"
        ((FAILED++))
    fi
}

echo ""
print_info "Checking Backend Files..."

# Check ProductMatchingService.ts
check_file_content "packages/nc-product-matching/src/services/ProductMatchingService.ts" "nc_external_products" "ProductMatchingService.ts - Dynamic category loading"

# Check ProductMatchingService.js (compiled)
check_file_content "packages/nc-product-matching/dist/services/ProductMatchingService.js" "nc_external_products" "ProductMatchingService.js - Compiled dynamic category loading"

# Check EnhancedMatchingEngine.ts
check_file_content "packages/nc-product-matching/src/helpers/EnhancedMatchingEngine.ts" "similarity.overall < 0.10" "EnhancedMatchingEngine.ts - 10% threshold"

# Check EnhancedMatchingEngine.js (compiled)
check_file_content "packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js" "similarity.overall < 0.10" "EnhancedMatchingEngine.js - 10% threshold (compiled)"

# Check server.js
check_file_content "packages/nc-product-matching/server.js" "/filter-options/refresh" "server.js - Refresh endpoint"

echo ""
print_info "Checking Frontend Files..."

# Check view.vue
check_file_content "packages/nc-gui/components/workspace/product-matcher/view.vue" "All Product Category" "view.vue - Product category label"
check_file_content "packages/nc-gui/components/workspace/product-matcher/view.vue" "display: none" "view.vue - Hidden categories filter"
check_file_content "packages/nc-gui/components/workspace/product-matcher/view.vue" "border-2" "view.vue - Enhanced borders"

# Check useProductMatching.ts
check_file_content "packages/nc-gui/composables/useProductMatching.ts" "let options:" "useProductMatching.ts - Fixed const/let issue"
check_file_content "packages/nc-gui/composables/useProductMatching.ts" "refreshFilterOptions" "useProductMatching.ts - Refresh functionality"

# Check useProductMatchingApi.ts
check_file_content "packages/nc-gui/composables/useProductMatchingApi.ts" "refreshFilterOptions" "useProductMatchingApi.ts - Refresh API method"

echo ""
print_info "Testing API Endpoints (if services are running)..."

# Test filter options endpoint
if curl -s -f "http://localhost:8087/filter-options" > /dev/null 2>&1; then
    print_status "Filter options endpoint responding"
    ((PASSED++))
    
    # Check if response contains product categories
    RESPONSE=$(curl -s "http://localhost:8087/filter-options")
    if echo "$RESPONSE" | grep -q "sources"; then
        print_status "Filter options contains sources data"
        ((PASSED++))
    else
        print_warning "Filter options response may be empty"
        ((FAILED++))
    fi
else
    print_warning "Filter options endpoint not responding (service may not be running)"
fi

# Test refresh endpoint
if curl -s -f "http://localhost:8087/filter-options/refresh" > /dev/null 2>&1; then
    print_status "Refresh endpoint responding"
    ((PASSED++))
else
    print_warning "Refresh endpoint not responding (service may not be running)"
fi

# Test candidates endpoint
if curl -s -f "http://localhost:8087/products/1685/candidates" > /dev/null 2>&1; then
    print_status "Candidates endpoint responding"
    ((PASSED++))
    
    # Check if response contains items
    RESPONSE=$(curl -s "http://localhost:8087/products/1685/candidates")
    if echo "$RESPONSE" | grep -q '"items":\['; then
        print_status "Candidates endpoint returning data"
        ((PASSED++))
    else
        print_warning "Candidates endpoint may be returning empty results"
    fi
else
    print_warning "Candidates endpoint not responding (service may not be running)"
fi

echo ""
echo "📊 Verification Summary"
echo "======================"
print_status "Passed: $PASSED"
if [ $FAILED -gt 0 ]; then
    print_error "Failed: $FAILED"
else
    print_status "Failed: $FAILED"
fi

echo ""
if [ $FAILED -eq 0 ]; then
    print_status "🎉 All verifications passed! Deployment successful."
    echo ""
    print_info "Next steps:"
    echo "1. Test the Product Matcher interface in your browser"
    echo "2. Verify that candidates appear when selecting products"
    echo "3. Test the product category filter functionality"
    echo "4. Check browser console for any JavaScript errors"
else
    print_error "❌ Some verifications failed. Please check the issues above."
    echo ""
    print_info "Troubleshooting:"
    echo "1. Ensure all files were copied correctly"
    echo "2. Check that services are running"
    echo "3. Verify database connectivity"
    echo "4. Review the deployment guide for manual steps"
fi

echo ""
print_info "For detailed deployment instructions, see: DEPLOYMENT_GUIDE.md"
print_info "For changes summary, see: CHANGES_SUMMARY.md"
