# Product Matcher Migration Deployment Guide

## 📋 Overview

This migration package contains all the changes made to fix the Product Matcher functionality, including:
- Dynamic product category filtering from `nc_external_products` table
- Fixed minimum score threshold (30% → 10%) to show candidates
- UI improvements and bug fixes
- Enhanced caching and refresh capabilities

## 📁 File Structure

```
deploy_migration/
├── backend/
│   └── packages/nc-product-matching/
│       ├── server.js
│       ├── src/
│       │   ├── services/
│       │   │   └── ProductMatchingService.ts
│       │   └── helpers/
│       │       └── EnhancedMatchingEngine.ts
│       └── dist/
│           ├── services/
│           │   └── ProductMatchingService.js
│           └── helpers/
│               └── EnhancedMatchingEngine.js
└── frontend/
    └── packages/nc-gui/
        ├── components/workspace/product-matcher/
        │   └── view.vue
        └── composables/
            ├── useProductMatchingApi.ts
            └── useProductMatching.ts
```

## 🔧 Prerequisites

- Node.js (v18+)
- pnpm package manager
- PostgreSQL database
- Existing NocoDB installation

## 📊 Database Requirements

Ensure your database has the `nc_external_products` table with the following structure:
```sql
CREATE TABLE nc_external_products (
    id BIGINT PRIMARY KEY,
    external_product_key TEXT,
    source_id TEXT,
    product_name TEXT,
    brand TEXT,
    product_category TEXT,  -- This field is critical for filtering
    long_description TEXT,
    ean TEXT,
    sku TEXT,
    price NUMERIC,
    image TEXT,
    url TEXT,
    -- ... other fields
);
```

## 🚀 Deployment Steps

### Step 1: Backup Current Files (Recommended)

```bash
# Create backup directory
mkdir -p /backup/product-matcher-$(date +%Y%m%d)

# Backup current files
cp packages/nc-product-matching/src/services/ProductMatchingService.ts /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-product-matching/dist/services/ProductMatchingService.js /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-product-matching/server.js /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-product-matching/src/helpers/EnhancedMatchingEngine.ts /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-gui/components/workspace/product-matcher/view.vue /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-gui/composables/useProductMatchingApi.ts /backup/product-matcher-$(date +%Y%m%d)/
cp packages/nc-gui/composables/useProductMatching.ts /backup/product-matcher-$(date +%Y%m%d)/
```

### Step 2: Deploy Backend Changes

```bash
# Navigate to your NocoDB installation
cd /path/to/your/nocodb

# Copy backend files
cp deploy_migration/backend/packages/nc-product-matching/server.js packages/nc-product-matching/
cp deploy_migration/backend/packages/nc-product-matching/src/services/ProductMatchingService.ts packages/nc-product-matching/src/services/
cp deploy_migration/backend/packages/nc-product-matching/dist/services/ProductMatchingService.js packages/nc-product-matching/dist/services/
cp deploy_migration/backend/packages/nc-product-matching/src/helpers/EnhancedMatchingEngine.ts packages/nc-product-matching/src/helpers/
cp deploy_migration/backend/packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js packages/nc-product-matching/dist/helpers/
```

### Step 3: Deploy Frontend Changes

```bash
# Copy frontend files
cp deploy_migration/frontend/packages/nc-gui/components/workspace/product-matcher/view.vue packages/nc-gui/components/workspace/product-matcher/
cp deploy_migration/frontend/packages/nc-gui/composables/useProductMatchingApi.ts packages/nc-gui/composables/
cp deploy_migration/frontend/packages/nc-gui/composables/useProductMatching.ts packages/nc-gui/composables/
```

### Step 4: Restart Services

#### Main NocoDB Backend
```bash
cd /path/to/your/nocodb
PORT=8086 NC_DB="pg://localhost:5432?u=devuser&p=VerifyTen102025&d=nocodb" HOST=0.0.0.0 pnpm --filter=nocodb run start
```

#### Product Matching Service
```bash
cd /path/to/your/nocodb/packages/nc-product-matching
DB_NAME=pim DB_USER=devuser DB_PASSWORD=VerifyTen102025 HOST=0.0.0.0 PORT=8087 pnpm start
```

#### Frontend
```bash
cd /path/to/your/nocodb/packages/nc-gui
HOST=0.0.0.0 PORT=3005 NUXT_PUBLIC_NC_BACKEND_URL=http://localhost:8086 pnpm run dev
```

## 🔍 Verification Steps

### 1. Test Product Category Filter
- Open the Product Matcher interface
- Check that "All Product Category" dropdown shows proper categories (not website domains)
- Verify categories are loaded from `nc_external_products.product_category`

### 2. Test Candidate Display
- Click on any product in the left panel
- Verify that candidates appear in the right panel
- Check that match scores are displayed (should be 10%+ now)

### 3. Test Filtering
- Select a product category from the dropdown
- Verify that the right panel filters candidates by the selected category

### 4. Test API Endpoints
```bash
# Test filter options
curl -X GET "http://localhost:8087/filter-options" -H "Content-Type: application/json"

# Test refresh endpoint
curl -X GET "http://localhost:8087/filter-options/refresh" -H "Content-Type: application/json"

# Test candidates endpoint
curl -X GET "http://localhost:8087/products/1685/candidates" -H "Content-Type: application/json"
```

## 🐛 Troubleshooting

### Issue: No candidates showing in right panel
**Solution**: Check that the minimum score threshold was properly updated to 10%
```bash
grep -n "similarity.overall < 0.10" packages/nc-product-matching/dist/helpers/EnhancedMatchingEngine.js
```

### Issue: Product categories showing as website domains
**Solution**: Verify that the service is fetching from `nc_external_products` table
```bash
grep -n "nc_external_products" packages/nc-product-matching/dist/services/ProductMatchingService.js
```

### Issue: JavaScript error "invalid assignment to const"
**Solution**: Ensure the frontend fix was applied
```bash
grep -n "let options:" packages/nc-gui/composables/useProductMatching.ts
```

### Issue: Server not starting
**Solution**: Check environment variables and database connection
```bash
# Test database connection
psql -h localhost -U devuser -d pim -c "SELECT COUNT(*) FROM nc_external_products;"
```

## 📝 Key Changes Summary

### Backend Changes
1. **ProductMatchingService.ts**: Dynamic category loading from `nc_external_products`
2. **EnhancedMatchingEngine.ts**: Lowered minimum score threshold from 30% to 10%
3. **server.js**: Added refresh endpoint for filter options
4. **Caching**: Reduced cache TTL from 5 minutes to 2 minutes

### Frontend Changes
1. **view.vue**: UI improvements, hidden categories filter, renamed sources to product category
2. **useProductMatching.ts**: Fixed JavaScript error, added refresh functionality
3. **useProductMatchingApi.ts**: Added refresh API method

## 🔄 Rollback Instructions

If you need to rollback the changes:

```bash
# Restore from backup
cp /backup/product-matcher-$(date +%Y%m%d)/* packages/nc-product-matching/src/services/
cp /backup/product-matcher-$(date +%Y%m%d)/* packages/nc-product-matching/dist/services/
# ... repeat for all files

# Restart services
```

## 📞 Support

If you encounter any issues during deployment:
1. Check the server logs for error messages
2. Verify database connectivity and table structure
3. Ensure all environment variables are set correctly
4. Test API endpoints individually

## 🎯 Expected Results

After successful deployment:
- ✅ Product categories load dynamically from database
- ✅ Candidates appear when selecting products (10%+ match scores)
- ✅ Product category filter works in right panel
- ✅ No JavaScript errors in browser console
- ✅ Match scores display below match buttons
- ✅ Enhanced borders around product rows
