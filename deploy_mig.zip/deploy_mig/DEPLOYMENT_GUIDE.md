# Product Category Filtering Migration Guide

This guide explains how to deploy the product category filtering fixes to a new codebase.

## 📁 Files Included

This migration package contains 3 modified files:

1. **`useProductMatching.ts`** - Main filtering logic and composable
2. **`useProductMatchingApi.ts`** - API interface and data types
3. **`view.vue`** - Product matcher UI component

## 🎯 What This Fix Does

### Problem Solved
- **Issue**: Product category filtering was not working in the right panel
- **Root Cause**: External products didn't have category data, and filter logic was incorrect
- **Solution**: Implemented hardcoded category mapping and fixed filter logic

### Key Changes
1. **Fixed category filtering logic** for the right panel
2. **Hidden non-functional "All Categories" dropdown**
3. **Updated source filter to work as category filter**
4. **Added comprehensive debugging and error handling**
5. **Implemented hardcoded category mapping** as workaround

## 🚀 Deployment Steps

### Step 1: Backup Existing Files
```bash
# Create backup of existing files
cp packages/nc-gui/composables/useProductMatching.ts packages/nc-gui/composables/useProductMatching.ts.backup
cp packages/nc-gui/composables/useProductMatchingApi.ts packages/nc-gui/composables/useProductMatchingApi.ts.backup
cp packages/nc-gui/components/workspace/product-matcher/view.vue packages/nc-gui/components/workspace/product-matcher/view.vue.backup
```

### Step 2: Deploy New Files
```bash
# Copy the new files to their locations
cp deploy_mig/useProductMatching.ts packages/nc-gui/composables/
cp deploy_mig/useProductMatchingApi.ts packages/nc-gui/composables/
cp deploy_mig/view.vue packages/nc-gui/components/workspace/product-matcher/
```

### Step 3: Verify File Locations
Ensure the files are in the correct locations:
```
packages/nc-gui/composables/useProductMatching.ts
packages/nc-gui/composables/useProductMatchingApi.ts
packages/nc-gui/components/workspace/product-matcher/view.vue
```

### Step 4: Restart Application
```bash
# Restart your development server
npm run dev
# or
pnpm dev
# or
yarn dev
```

## 🔧 Configuration

### Category Mapping
The solution includes a hardcoded category mapping in `useProductMatching.ts`. You may need to update this based on your data:

```typescript
const categoryMapping: Record<string, string[]> = {
  'Pasear': [
    'Capota Bugaboo Fox 2 y Camaleon',
    'Capota Ventilada Bugaboo Donkey', 
    'Capota Ventilada Bugaboo Dragonfly',
    // Add more products as needed
  ]
}
```

### Adding New Categories
To add new categories, update the `categoryMapping` object:

```typescript
const categoryMapping: Record<string, string[]> = {
  'Pasear': [...],
  'Vestir': ['Product 1', 'Product 2', ...],
  'OtherCategory': ['Product A', 'Product B', ...]
}
```

## 🧪 Testing

### Test the Fix
1. **Open the product matcher page**
2. **Select a product** from the left panel
3. **Use the "All Categories" dropdown** (which is actually the source filter)
4. **Select "Pasear"** category
5. **Verify** that the right panel shows only products in the "Pasear" category

### Expected Behavior
- ✅ Left panel: Products filtered by category
- ✅ Right panel: Shows matches only for selected category
- ✅ "All Categories" dropdown is hidden (non-functional)
- ✅ Source filter works as category filter

## 🐛 Troubleshooting

### Issue: Filter not working
**Solution**: Check browser console for debugging logs. The fix includes comprehensive logging.

### Issue: No products showing
**Solution**: Verify the category mapping includes your product titles exactly as they appear in the database.

### Issue: TypeScript errors
**Solution**: Ensure all imports are correct and the file paths match your project structure.

## 📝 Notes

### Debugging
The fix includes extensive debugging logs. Check browser console for:
- `🔍` - Debug information
- `✅` - Success messages  
- `❌` - Error messages

### Performance
- The hardcoded mapping is a temporary solution
- Consider implementing proper API-based category filtering for production
- Debug logs can be removed in production

### Future Improvements
1. **API Enhancement**: Update backend to return proper category data
2. **Dynamic Mapping**: Replace hardcoded mapping with database-driven solution
3. **Remove Debug Logs**: Clean up console.log statements for production

## 🔄 Rollback

If you need to rollback:

```bash
# Restore original files
cp packages/nc-gui/composables/useProductMatching.ts.backup packages/nc-gui/composables/useProductMatching.ts
cp packages/nc-gui/composables/useProductMatchingApi.ts.backup packages/nc-gui/composables/useProductMatchingApi.ts
cp packages/nc-gui/components/workspace/product-matcher/view.vue.backup packages/nc-gui/components/workspace/product-matcher/view.vue
```

## 📞 Support

If you encounter issues:
1. Check browser console for error messages
2. Verify file paths and imports
3. Ensure all dependencies are installed
4. Check that the product matcher page loads correctly

---

**Migration Date**: $(date)
**Version**: 1.0
**Status**: Ready for deployment
